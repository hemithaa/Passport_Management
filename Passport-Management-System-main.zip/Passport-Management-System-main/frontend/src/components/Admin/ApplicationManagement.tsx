import React, { useState, useEffect } from 'react';
import axiosInstance from '../../services/axiosInstance';
import { getStatusColor, getStatusIcon } from '../../utils';
import { PassportList } from './PassportList/PassportList';
import { VisaList } from './VisaList/VisaList';
import { PassportDetailsModal } from './Modals/PassportDetailsModal/PassportDetailsModal';
import { VisaDetailsModal } from './Modals/VisaDetailsModal/VisaDetailsModal';
import type { BackendPassportApplication, BackendVisaApplication } from '../../types';

const ApplicationManagement: React.FC = () => {
  const [activeTab, setActiveTab] = useState<'passport' | 'visa'>('passport');
  const [passportApps, setPassportApps] = useState<BackendPassportApplication[]>([]);
  const [visaApps, setVisaApps] = useState<BackendVisaApplication[]>([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  
  // Modal states
  const [selectedPassport, setSelectedPassport] = useState<BackendPassportApplication | null>(null);
  const [selectedVisa, setSelectedVisa] = useState<BackendVisaApplication | null>(null);
  const [showPassportModal, setShowPassportModal] = useState(false);
  const [showVisaModal, setShowVisaModal] = useState(false);

  useEffect(() => {
    fetchApplications();
  }, [activeTab]);

  const fetchApplications = async () => {
    setLoading(true);
    setError(null);
    
    try {
      if (activeTab === 'passport') {
        const response = await axiosInstance.get('/api/passport/all');
        setPassportApps(response.data);
      } else {
        const response = await axiosInstance.get('/api/visa/all');
        setVisaApps(response.data);
      }
    } catch (err: any) {
      setError(err.response?.data?.message || 'Failed to fetch applications');
      console.error('Error fetching applications:', err);
    } finally {
      setLoading(false);
    }
  };

  const handlePassportStatusChange = async (
    applicationId: number, 
    newStatus: string
  ) => {
    try {
      await axiosInstance.put(
        `/api/passport/status/${applicationId}?status=${newStatus}`
      );
      
      // Update local state
      setPassportApps(apps => 
        apps.map(app => 
          app.passportApplicationId === applicationId 
            ? { ...app, status: newStatus as any }
            : app
        )
      );
    } catch (err: any) {
      setError(err.response?.data?.message || 'Failed to update status');
      console.error('Error updating passport status:', err);
    }
  };

  const handleVisaStatusChange = async (
    visaId: string, 
    newStatus: string
  ) => {
    try {
      await axiosInstance.put(
        `/api/visa/${visaId}/status?status=${newStatus}`
      );
      
      // Update local state
      setVisaApps(apps => 
        apps.map(app => 
          app.visaId === visaId 
            ? { ...app, status: newStatus as any }
            : app
        )
      );
    } catch (err: any) {
      setError(err.response?.data?.message || 'Failed to update status');
      console.error('Error updating visa status:', err);
    }
  };

  const handleViewPassportDetails = (passport: BackendPassportApplication) => {
    setSelectedPassport(passport);
    setShowPassportModal(true);
  };

  const handleViewVisaDetails = (visa: BackendVisaApplication) => {
    setSelectedVisa(visa);
    setShowVisaModal(true);
  };

  const closePassportModal = () => {
    setShowPassportModal(false);
    setSelectedPassport(null);
  };

  const closeVisaModal = () => {
    setShowVisaModal(false);
    setSelectedVisa(null);
  };
  
  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString();
  };

  if (loading) {
    return (
      <div className="management-container">
        <div className="loading">Loading applications...</div>
      </div>
    );
  }

  return (
    <div className="management-container">
      <div className="management-header">
        <h2>Application Management</h2>
        <div className="tab-switcher">
          <button
            className={`tab-btn ${activeTab === 'passport' ? 'active' : ''}`}
            onClick={() => setActiveTab('passport')}
          >
            Passport Applications
          </button>
          <button
            className={`tab-btn ${activeTab === 'visa' ? 'active' : ''}`}
            onClick={() => setActiveTab('visa')}
          >
            Visa Applications
          </button>
        </div>
      </div>

      {error && (
        <div className="error-message">
          {error}
          <button onClick={fetchApplications} className="retry-btn">
            Retry
          </button>
        </div>
      )}

      {activeTab === 'passport' && (
        <PassportList 
          passportApps={passportApps} 
          formatDate={formatDate} 
          getStatusColor={getStatusColor} 
          getStatusIcon={getStatusIcon} 
          handlePassportStatusChange={handlePassportStatusChange}
          onViewDetails={handleViewPassportDetails}
        />
      )}

      {activeTab === 'visa' && (
        <VisaList 
          visaApps={visaApps} 
          formatDate={formatDate} 
          getStatusColor={getStatusColor} 
          getStatusIcon={getStatusIcon} 
          handleVisaStatusChange={handleVisaStatusChange}
          onViewDetails={handleViewVisaDetails}
        />
      )}

      {/* Modals */}
      {showPassportModal && selectedPassport && (
        <PassportDetailsModal
          passport={selectedPassport}
          onClose={closePassportModal}
          formatDate={formatDate}
          getStatusColor={getStatusColor}
          getStatusIcon={getStatusIcon}
        />
      )}

      {showVisaModal && selectedVisa && (
        <VisaDetailsModal
          visa={selectedVisa}
          onClose={closeVisaModal}
          formatDate={formatDate}
          getStatusColor={getStatusColor}
          getStatusIcon={getStatusIcon}
        />
      )}
    </div>
  );
};

export default ApplicationManagement;