{
    "userId": "PASS-0070",
    "customerId": "616972",
    "firstName": "Hariprasath",
    "lastName": "S",
    "email": "hariprasathoff2306@gmail.com",
    "phoneNumber": "9876543210",
    "dateOfBirth": "1990-05-15",
    "age": 35,
    "address": "123, Gandhi Street, Near City Center",
    "pincode": "600001",
    "city": "11",
    "state": "Tamil Nadu",
    "citizenType": "ADULT",
    "occupation": "PRIVATE_EMPLOYEE",
    "registrationType": "PASSPORT",
    "createdAt": "2025-08-02T10:13:03.169978"
}

{
    "passportApplicationId": 1,
    "userId": "PASS-0070",
    "passportId": "FPS-307626",
    "serviceTypeId": 1,
    "bookletTypeId": 1,
    "passportType": "NEW",
    "applicationDate": "2025-08-02",
    "issueDate": "2025-08-17",
    "expiryDate": "2035-08-17",
    "status": "PENDING",
    "amountPaid": 2500.00,
    "previousPassportId": null,
    "processingDays": 15,
    "userFirstName": "Hariprasath",
    "userLastName": "S",
    "userPhone": "9876543210",
    "userEmail": "hariprasathoff2306@gmail.com",
    "userCitizenType": "ADULT",
    "createdAt": "2025-08-02T10:28:04.249902",
    "updatedAt": "2025-08-02T10:28:04.249902"
}

{
    "visaApplicationId": 1,
    "userId": "PASS-0070",
    "visaId": "VISA-6166",
    "passportId": "FPS-307626",
    "destinationCountry": "Canada",
    "visaType": "Tourist",
    "applicationDate": "2025-08-02",
    "issueDate": "2025-08-02",
    "expiryDate": "2028-08-02",
    "validityYears": 3.0,
    "status": "PENDING",
    "amountPaid": 1500.00,
    "userFirstName": "Hariprasath",
    "userLastName": "S",
    "userPhone": "9876543210",
    "userEmail": "hariprasathoff2306@gmail.com",
    "userOccupation": "PRIVATE_EMPLOYEE",
    "createdAt": "2025-08-02T10:49:37.557641",
    "updatedAt": "2025-08-02T10:49:37.557641"
}


{
    "cancellationId": 1,
    "visaApplicationId": 1,
    "userId": "PASS-0070",
    "cancellationDate": "2025-08-02",
    "cancellationReason": "Change of travel plans",
    "refundAmount": 750.000,
    "status": "REQUESTED",
    "createdAt": "2025-08-02T11:54:33.588194",
    "updatedAt": "2025-08-02T11:54:33.588194"
}

//We can register a user, apply for passport and apply for visa, cancel the visa and change the status....
