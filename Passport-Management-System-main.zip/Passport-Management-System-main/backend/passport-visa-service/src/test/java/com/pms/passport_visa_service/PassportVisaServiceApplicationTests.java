package com.pms.passport_visa_service;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PassportVisaServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
