export const countries = [
  'United States', 'United Kingdom', 'Canada', 'Australia', 'Germany',
  'France', 'Japan', 'Singapore', 'UAE', 'Malaysia'
];

export const visaTypes = [
  'Tourist', 'Business', 'Student', 'Work', 'Transit'
];

export const occupationTypes = [
  'PRIVATE_EMPLOYEE', 'GOVERNMENT_EMPLOYEE', 'SELF_EMPLOYED', 'STUDENT', 'RETIRED_EMPLOYEE'
];
